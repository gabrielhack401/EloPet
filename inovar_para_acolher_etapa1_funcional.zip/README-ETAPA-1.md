# Inovar para Acolher — Etapa 1: núcleo funcional

Este pacote foi construído sobre o código-fonte enviado.

## O que entrou nesta etapa
1. Perfil de usuário criado no Firestore no cadastro (`role: citizen` por padrão).
2. Serviço para consultar e atualizar o perfil.
3. Caixa de solicitações de adoção para o responsável pelo animal.
4. Ações de análise, aprovação e recusa de pedidos.
5. Registro de vacinação, consulta, castração, tratamento e outros cuidados.
6. Histórico de saúde associado ao animal.
7. Acesso ao histórico de saúde a partir dos detalhes do animal.
8. Atalho de gestão de adoções no perfil.

## Instalação
1. Faça uma cópia de segurança integral do seu projeto.
2. Copie `lib/` e `firebase/` deste pacote para a raiz do projeto, mesclando as pastas.
3. Execute:
   ```bash
   flutter pub get
   dart format lib
   flutter analyze
   ```
4. Revise as regras em `firebase/firestore.rules` e publique no Firebase Console > Firestore Database > Rules somente depois de conferir o projeto e testar em ambiente de desenvolvimento.

## Atenção
- Esta é a Etapa 1, não a entrega final das 40 funções.
- A role `citizen` é criada automaticamente. Não há botão público para se tornar administrador. Atribuição de funções privilegiadas deve ser feita por processo confiável (Firebase Admin SDK / ambiente administrativo protegido), nunca pelo próprio usuário no app.
- O registro de saúde deve ser preenchido por pessoa autorizada e conferido por profissional. O app não substitui prontuário veterinário.
- A tela de gestão lista solicitações ligadas ao UID que cadastrou o animal. Se você cadastrar animais como usuário cidadão, essa é a conta que verá as solicitações.
- A publicação das regras pode exigir índices compostos do Firestore. O console informa quando um índice precisa ser criado.
- Faça testes com contas e dados fictícios antes de usar informações reais.
