import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class ManagementService {
  final _db = FirebaseFirestore.instance;
  String get uid => FirebaseAuth.instance.currentUser?.uid ?? '';

  Stream<QuerySnapshot<Map<String, dynamic>>> adoptionInbox() {
    if (uid.isEmpty) return const Stream.empty();
    return _db.collection('adoptionRequests')
      .where('shelterId', isEqualTo: uid)
      .orderBy('createdAt', descending: true).snapshots();
  }

  Future<void> updateAdoptionStatus(String requestId, String status) async {
    const allowed = {'em_analise', 'aprovada', 'recusada', 'cancelada'};
    if (!allowed.contains(status)) throw ArgumentError('Status inválido.');
    if (uid.isEmpty) throw StateError('Faça login novamente.');
    await _db.collection('adoptionRequests').doc(requestId).update({
      'status': status,
      'reviewedAt': FieldValue.serverTimestamp(),
      'reviewedBy': uid,
    });
  }

  Future<void> addHealthRecord({
    required String animalId,
    required String animalName,
    required String category,
    required String description,
    String? professional,
    DateTime? eventDate,
  }) async {
    if (uid.isEmpty) throw StateError('Faça login novamente.');
    await _db.collection('animalHealthRecords').add({
      'animalId': animalId,
      'animalName': animalName,
      'shelterId': uid,
      'category': category,
      'description': description.trim(),
      'professional': (professional ?? '').trim(),
      'eventDate': Timestamp.fromDate(eventDate ?? DateTime.now()),
      'createdAt': FieldValue.serverTimestamp(),
    });
  }

  Stream<QuerySnapshot<Map<String, dynamic>>> healthRecords(String animalId) {
    return _db.collection('animalHealthRecords')
      .where('animalId', isEqualTo: animalId)
      .orderBy('eventDate', descending: true).snapshots();
  }
}
