import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import '../models/animal.dart';
import '../services/management_service.dart';

class AnimalHealthScreen extends StatefulWidget {
  const AnimalHealthScreen({super.key, required this.animal});
  final Animal animal;
  @override
  State<AnimalHealthScreen> createState() => _AnimalHealthScreenState();
}

class _AnimalHealthScreenState extends State<AnimalHealthScreen> {
  final _description = TextEditingController();
  final _professional = TextEditingController();
  String _category = 'Vacinação';
  bool _saving = false;
  final _service = ManagementService();

  Future<void> _save() async {
    if (_description.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Descreva o atendimento ou procedimento.')));
      return;
    }
    setState(() => _saving = true);
    try {
      await _service.addHealthRecord(
        animalId: widget.animal.id,
        animalName: widget.animal.name,
        category: _category,
        description: _description.text,
        professional: _professional.text,
      );
      _description.clear();
      _professional.clear();
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Registro de saúde salvo.')));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Erro: $e')));
    } finally { if (mounted) setState(() => _saving = false); }
  }

  @override
  void dispose() { _description.dispose(); _professional.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text('Saúde de ${widget.animal.name}')),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      DropdownButtonFormField<String>(
        value: _category,
        decoration: const InputDecoration(labelText: 'Tipo de registro'),
        items: const ['Vacinação','Consulta veterinária','Castração','Tratamento','Outro']
          .map((v) => DropdownMenuItem(value: v, child: Text(v))).toList(),
        onChanged: (v) => setState(() => _category = v ?? 'Vacinação'),
      ),
      const SizedBox(height: 12),
      TextField(controller: _description, minLines: 2, maxLines: 4,
        decoration: const InputDecoration(labelText: 'Descrição / observações')),
      const SizedBox(height: 12),
      TextField(controller: _professional, decoration: const InputDecoration(labelText: 'Profissional responsável (opcional)')),
      const SizedBox(height: 12),
      FilledButton.icon(onPressed: _saving ? null : _save,
        icon: const Icon(Icons.save), label: Text(_saving ? 'Salvando...' : 'Salvar registro')),
      const SizedBox(height: 24),
      Text('Histórico', style: Theme.of(context).textTheme.titleLarge),
      StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: _service.healthRecords(widget.animal.id),
        builder: (context, snapshot) {
          if (snapshot.hasError) return const Text('Erro ao carregar histórico. Verifique regras e índices.');
          if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
          if (snapshot.data!.docs.isEmpty) return const Text('Nenhum registro de saúde ainda.');
          return Column(children: snapshot.data!.docs.map((d) {
            final m=d.data();
            final date=m['eventDate'] is Timestamp ? (m['eventDate'] as Timestamp).toDate() : null;
            return Card(child: ListTile(
              leading: const Icon(Icons.medical_services_outlined),
              title: Text(m['category'] ?? 'Atendimento'),
              subtitle: Text('${m['description'] ?? ''}\n${date == null ? '' : '${date.day.toString().padLeft(2,'0')}/${date.month.toString().padLeft(2,'0')}/${date.year}'}${(m['professional'] ?? '').toString().isEmpty ? '' : '\n${m['professional']}'}'),
              isThreeLine: true,
            ));
          }).toList());
        },
      ),
    ]),
  );
}
