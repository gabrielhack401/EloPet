import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import '../services/management_service.dart';

class AdoptionManagementScreen extends StatelessWidget {
  const AdoptionManagementScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final service = ManagementService();
    return Scaffold(
      appBar: AppBar(title: const Text('Gerenciar adoções')),
      body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: service.adoptionInbox(),
        builder: (context, snapshot) {
          if (snapshot.hasError) return const Center(child: Padding(
            padding: EdgeInsets.all(24),
            child: Text('Não foi possível carregar a caixa de adoções. Verifique as regras e o índice do Firestore.'),
          ));
          if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
          final docs = snapshot.data!.docs;
          if (docs.isEmpty) return const Center(child: Text('Nenhuma solicitação recebida para os seus animais.'));
          return ListView.builder(
            padding: const EdgeInsets.all(14),
            itemCount: docs.length,
            itemBuilder: (context, index) {
              final doc = docs[index];
              final data = doc.data();
              final status = data['status'] ?? 'pendente';
              return Card(child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(data['animalName'] ?? 'Animal', style: Theme.of(context).textTheme.titleMedium),
                  const SizedBox(height: 5),
                  Text('Interessado: ${data['adopterEmail'] ?? 'Não informado'}'),
                  Text('Situação: $status'),
                  if ((data['message'] ?? '').toString().isNotEmpty) ...[
                    const SizedBox(height: 8),
                    Text(data['message']),
                  ],
                  const SizedBox(height: 10),
                  Wrap(spacing: 8, children: [
                    OutlinedButton(onPressed: () => _change(context, service, doc.id, 'em_analise'), child: const Text('Em análise')),
                    FilledButton(onPressed: () => _change(context, service, doc.id, 'aprovada'), child: const Text('Aprovar')),
                    TextButton(onPressed: () => _change(context, service, doc.id, 'recusada'), child: const Text('Recusar')),
                  ]),
                ]),
              ));
            },
          );
        },
      ),
    );
  }

  Future<void> _change(BuildContext context, ManagementService service, String id, String status) async {
    try {
      await service.updateAdoptionStatus(id, status);
      if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Solicitação atualizada.')));
    } catch (e) {
      if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Erro: $e')));
    }
  }
}
