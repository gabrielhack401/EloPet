import 'package:flutter/material.dart';
import '../models/animal.dart';
import '../services/animal_service.dart';
import '../services/auth_service.dart';
import 'animal_detail_screen.dart';
import 'new_animal_screen.dart';
import 'adoption_management_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _search = TextEditingController();
  String _category = 'Todos';
  String _listingType = 'adocao';
  final _categories = ['Todos', 'Cachorro', 'Gato', 'Outros'];

  @override
  void dispose() { _search.dispose(); super.dispose(); }

  bool _matches(Animal a) {
    final q = _search.text.trim().toLowerCase();
    final categoryOk = _category == 'Todos' || (_category == 'Outros' ? !['cachorro','gato'].contains(a.species.toLowerCase()) : a.species.toLowerCase() == _category.toLowerCase());
    return a.listingType == _listingType && categoryOk && (q.isEmpty || '${a.name} ${a.species} ${a.city}'.toLowerCase().contains(q));
  }

  @override
  Widget build(BuildContext context) {
    const green = Color(0xFF176B3A);
    return Scaffold(
      backgroundColor: const Color(0xFFF6F8F6),
      appBar: AppBar(backgroundColor: Colors.white, titleSpacing: 18, title: const Row(children: [Icon(Icons.pets, color: green), SizedBox(width: 8), Text('Inovar para Acolher', style: TextStyle(fontWeight: FontWeight.w800, color: Color(0xFF183B27)))]), actions: [
        IconButton(tooltip: 'Solicitações de adoção', onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AdoptionManagementScreen())), icon: const Icon(Icons.inbox_outlined)),
        IconButton(tooltip: 'Sair', onPressed: () => AuthService().signOut(), icon: const Icon(Icons.logout)),
      ]),
      floatingActionButton: FloatingActionButton.extended(backgroundColor: green, foregroundColor: Colors.white, onPressed: () async { await Navigator.push(context, MaterialPageRoute(builder: (_) => const NewAnimalScreen())); }, icon: const Icon(Icons.add), label: const Text('Anunciar animal')),
      body: StreamBuilder<List<Animal>>(
        stream: AnimalService().availableAnimals(),
        builder: (context, snapshot) {
          if (snapshot.hasError) return const Center(child: Text('Erro ao carregar anúncios. Confira as regras do Firebase.'));
          if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
          final all = snapshot.data!;
          final animals = all.where(_matches).toList();
          return CustomScrollView(slivers: [
            SliverToBoxAdapter(child: Container(color: Colors.white, padding: const EdgeInsets.fromLTRB(20, 12, 20, 20), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Container(width: double.infinity, padding: const EdgeInsets.all(20), decoration: BoxDecoration(borderRadius: BorderRadius.circular(22), gradient: const LinearGradient(colors: [Color(0xFF145C32), Color(0xFF2C8A50)])), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(_listingType == 'adocao' ? 'ADOÇÃO RESPONSÁVEL' : 'COMPRA RESPONSÁVEL', style: TextStyle(color: Color(0xFFD4F1D9), fontWeight: FontWeight.bold, letterSpacing: 1.2, fontSize: 11)), SizedBox(height: 8), Text(_listingType == 'adocao' ? 'Um novo amigo\npode estar aqui.' : 'Encontre seu\nnovo companheiro.', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 27, height: 1.1)), SizedBox(height: 8), Text(_listingType == 'adocao' ? 'Conheça animais que esperam por uma família.' : 'Veja animais anunciados por responsáveis.', style: TextStyle(color: Colors.white70))])),
              const SizedBox(height: 16), SegmentedButton<String>(segments: const [ButtonSegment(value: 'adocao', label: Text('Adotar'), icon: Icon(Icons.favorite)), ButtonSegment(value: 'venda', label: Text('Comprar'), icon: Icon(Icons.shopping_bag_outlined))], selected: {_listingType}, onSelectionChanged: (v) => setState(() => _listingType = v.first)), const SizedBox(height: 14), TextField(controller: _search, onChanged: (_) => setState(() {}), decoration: InputDecoration(hintText: 'Buscar por nome, espécie ou cidade', prefixIcon: const Icon(Icons.search), filled: true, fillColor: const Color(0xFFF2F5F2), border: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: BorderSide.none), suffixIcon: IconButton(onPressed: () { _search.clear(); setState(() {}); }, tooltip: 'Limpar busca', icon: const Icon(Icons.close)))),
              const SizedBox(height: 14), SizedBox(height: 40, child: ListView.separated(scrollDirection: Axis.horizontal, itemCount: _categories.length, separatorBuilder: (_, __) => const SizedBox(width: 8), itemBuilder: (context, i) { final c = _categories[i]; final selected = _category == c; return ChoiceChip(label: Text(c), selected: selected, onSelected: (_) => setState(() => _category = c), selectedColor: const Color(0xFFD9EBDD), labelStyle: TextStyle(color: selected ? green : Colors.black87, fontWeight: FontWeight.w600)); })),
              const SizedBox(height: 12), Row(children: [Text(_listingType == 'adocao' ? 'Animais para adoção' : 'Animais à venda', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w800)), const Spacer(), Text('${animals.length} anúncios', style: const TextStyle(color: Colors.black54, fontSize: 12))]),
            ]))),
            if (animals.isEmpty) SliverFillRemaining(hasScrollBody: false, child: Center(child: Padding(padding: const EdgeInsets.all(32), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [const Icon(Icons.search_off, size: 56, color: Colors.black26), const SizedBox(height: 12), Text(all.isEmpty ? 'Ainda não há animais anunciados.' : 'Nenhum animal encontrado.', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 17)), const SizedBox(height: 6), const Text('Tente mudar a busca ou seja o primeiro a publicar um anúncio.', textAlign: TextAlign.center)])))),
            if (animals.isNotEmpty) SliverPadding(padding: const EdgeInsets.fromLTRB(16, 4, 16, 100), sliver: SliverGrid(delegate: SliverChildBuilderDelegate((context, index) { final a = animals[index]; return InkWell(onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => AnimalDetailScreen(animal: a))), borderRadius: BorderRadius.circular(18), child: Card(color: Colors.white, elevation: 1, clipBehavior: Clip.antiAlias, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Expanded(child: Stack(fit: StackFit.expand, children: [Image.network(a.photoUrl, fit: BoxFit.cover, errorBuilder: (_, __, ___) => Container(color: const Color(0xFFEAF3EC), child: const Icon(Icons.pets, size: 48, color: green))), Positioned(left: 9, top: 9, child: Container(padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5), decoration: BoxDecoration(color: Colors.white.withValues(alpha: .94), borderRadius: BorderRadius.circular(20)), child: Text(a.species, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: green))))])), Padding(padding: const EdgeInsets.fromLTRB(11, 9, 11, 11), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(a.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)), const SizedBox(height: 4), Text('${a.age} • ${a.city}', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.black54, fontSize: 12)), const SizedBox(height: 7), Row(children: [Icon(a.listingType == 'adocao' ? Icons.favorite : Icons.payments_outlined, size: 14, color: green), const SizedBox(width: 4), Text(a.listingType == 'adocao' ? 'Adoção gratuita' : 'R$ ${a.price.toStringAsFixed(2).replaceAll('.', ',')}', style: const TextStyle(color: green, fontSize: 11, fontWeight: FontWeight.w700))])]))]))); }, childCount: animals.length), gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, mainAxisSpacing: 13, crossAxisSpacing: 13, childAspectRatio: .69))),
          ]);
        },
      ),
    );
  }
}
