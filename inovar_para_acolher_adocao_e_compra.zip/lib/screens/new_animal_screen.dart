import 'dart:io';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../models/animal.dart';
import '../services/animal_service.dart';

class NewAnimalScreen extends StatefulWidget {
  const NewAnimalScreen({super.key});
  @override
  State<NewAnimalScreen> createState() => _NewAnimalScreenState();
}

class _NewAnimalScreenState extends State<NewAnimalScreen> {
  final _formKey = GlobalKey<FormState>();
  final _name = TextEditingController();
  final _age = TextEditingController();
  final _city = TextEditingController();
  final _description = TextEditingController();
  final _price = TextEditingController();
  final _picker = ImagePicker();
  File? _photo;
  String _species = 'Cachorro';
  String _listingType = 'adocao';
  bool _busy = false;

  Future<void> _choosePhoto() async {
    final file = await _picker.pickImage(source: ImageSource.gallery, imageQuality: 82, maxWidth: 1800);
    if (file != null && mounted) setState(() => _photo = File(file.path));
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    if (_listingType == 'venda' && (double.tryParse(_price.text.replaceAll(',', '.')) ?? 0) <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Informe um preço válido para o anúncio de compra.')));
      return;
    }
    if (_photo == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('O envio de uma foto é obrigatório.')));
      return;
    }
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;
    setState(() => _busy = true);
    try {
      final ref = FirebaseStorage.instance.ref('animals/${user.uid}/${DateTime.now().millisecondsSinceEpoch}.jpg');
      final task = await ref.putFile(_photo!, SettableMetadata(contentType: 'image/jpeg'));
      final photoUrl = await task.ref.getDownloadURL();
      await AnimalService().addAnimal(Animal(
        id: '', name: _name.text.trim(), species: _species,
        description: _description.text.trim(), photoUrl: photoUrl,
        age: _age.text.trim(), city: _city.text.trim(), status: 'disponivel', shelterId: '',
        listingType: _listingType, price: _listingType == 'venda' ? double.parse(_price.text.replaceAll(',', '.')) : 0,
      ));
      if (mounted) Navigator.pop(context);
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Não foi possível publicar: $e')));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  void dispose() {
    for (final c in [_name, _age, _city, _description, _price]) { c.dispose(); }
    super.dispose();
  }

  InputDecoration _decoration(String label, IconData icon) => InputDecoration(
    labelText: label, prefixIcon: Icon(icon), filled: true,
    fillColor: const Color(0xFFF5F7F5), border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
  );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Anunciar animal')),
      body: Form(key: _formKey, child: ListView(padding: const EdgeInsets.all(20), children: [
        Text(_listingType == 'adocao' ? 'Vamos encontrar uma família?' : 'Anuncie com responsabilidade', style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold)),
        const SizedBox(height: 6), const Text('Escolha a modalidade e publique um anúncio completo.'),
        const SizedBox(height: 14),
        SegmentedButton<String>(segments: const [ButtonSegment(value: 'adocao', label: Text('Adoção'), icon: Icon(Icons.favorite)), ButtonSegment(value: 'venda', label: Text('Compra'), icon: Icon(Icons.shopping_bag_outlined))], selected: {_listingType}, onSelectionChanged: (v) => setState(() => _listingType = v.first)),
        const SizedBox(height: 10),
        if (_listingType == 'venda') ...[
          TextFormField(controller: _price, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: _decoration('Preço (R$) *', Icons.payments_outlined), validator: (v) => _listingType == 'venda' && (double.tryParse((v ?? '').replaceAll(',', '.')) ?? 0) <= 0 ? 'Informe um preço maior que zero' : null),
          const SizedBox(height: 10),
          const Text('Publique somente anúncios permitidos pela legislação e priorize o bem-estar do animal.', style: TextStyle(fontSize: 12, color: Colors.black54)),
        ],
        const SizedBox(height: 20),
        InkWell(onTap: _busy ? null : _choosePhoto, borderRadius: BorderRadius.circular(20), child: Container(
          height: 220, decoration: BoxDecoration(color: const Color(0xFFEAF3EC), borderRadius: BorderRadius.circular(20), border: Border.all(color: const Color(0xFFB8D4BE))),
          clipBehavior: Clip.antiAlias, child: _photo == null
            ? const Column(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(Icons.add_photo_alternate_outlined, size: 48, color: Color(0xFF287443)), SizedBox(height: 10), Text('ADICIONAR FOTO *', style: TextStyle(fontWeight: FontWeight.bold)), Text('Toque para escolher na galeria'), Text('Obrigatória • JPG/PNG')])
            : Stack(fit: StackFit.expand, children: [Image.file(_photo!, fit: BoxFit.cover), Positioned(right: 10, top: 10, child: CircleAvatar(backgroundColor: Colors.white, child: IconButton(onPressed: _choosePhoto, icon: const Icon(Icons.edit, color: Color(0xFF287443))))) ]),
        )),
        const SizedBox(height: 18),
        TextFormField(controller: _name, decoration: _decoration('Nome do animal *', Icons.pets), validator: (v) => v == null || v.trim().isEmpty ? 'Informe o nome' : null),
        const SizedBox(height: 12),
        DropdownButtonFormField<String>(value: _species, decoration: _decoration('Espécie', Icons.category_outlined), items: ['Cachorro','Gato','Coelho','Ave','Outro'].map((s) => DropdownMenuItem(value: s, child: Text(s))).toList(), onChanged: (v) => setState(() => _species = v!)),
        const SizedBox(height: 12),
        TextFormField(controller: _age, decoration: _decoration('Idade aproximada', Icons.cake_outlined), validator: (v) => v == null || v.trim().isEmpty ? 'Informe a idade aproximada' : null),
        const SizedBox(height: 12),
        TextFormField(controller: _city, decoration: _decoration('Cidade *', Icons.location_on_outlined), validator: (v) => v == null || v.trim().isEmpty ? 'Informe a cidade' : null),
        const SizedBox(height: 12),
        TextFormField(controller: _description, minLines: 3, maxLines: 5, decoration: _decoration('Conte a história e o jeito dele *', Icons.notes), validator: (v) => v == null || v.trim().length < 10 ? 'Escreva pelo menos 10 caracteres' : null),
        const SizedBox(height: 22),
        FilledButton.icon(onPressed: _busy ? null : _save, icon: _busy ? const SizedBox(width: 18,height: 18,child: CircularProgressIndicator(strokeWidth: 2,color: Colors.white)) : const Icon(Icons.publish), label: Text(_busy ? 'Enviando foto e publicando...' : 'Publicar anúncio'), style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(54))),
        const SizedBox(height: 10), const Text('* Campos obrigatórios. A foto é enviada ao Firebase Storage; não é necessário colar URL.', textAlign: TextAlign.center, style: TextStyle(fontSize: 12, color: Colors.black54)),
      ])),
    );
  }
}
