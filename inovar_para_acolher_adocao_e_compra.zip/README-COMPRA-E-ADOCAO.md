# Inovar para Acolher — modalidade Adoção e Compra

Esta atualização acrescenta duas modalidades de anúncio:

- **Adoção:** anúncio gratuito, com solicitação de adoção.
- **Compra:** anúncio com preço obrigatório maior que zero e registro de interesse enviado ao anunciante.

A foto continua obrigatória e é enviada pelo aplicativo ao Firebase Storage. O app grava a URL retornada pelo Storage no Firestore; a pessoa não precisa informar URL manualmente.

## Arquivos alterados
- `lib/models/animal.dart`: modalidade e preço do anúncio.
- `lib/screens/home_screen.dart`: alternância Adotar/Comprar e preço nos cartões.
- `lib/screens/new_animal_screen.dart`: seleção da modalidade e preço obrigatório na venda.
- `lib/screens/animal_detail_screen.dart`: preço e botão de interesse conforme modalidade.
- `lib/services/animal_service.dart`: gravação de interesse de compra.
- `firebase/firestore.rules`: permissões para interesse de compra e validação básica da modalidade/preço.

## Aplicação
Faça backup antes de copiar `lib/` e `firebase/` para o projeto. Preserve `firebase_options.dart`, `google-services.json`, keystore e configurações Android. Depois execute `flutter pub get`, `dart format lib` e `flutter analyze`.

## Importante
O registro de interesse não processa pagamento nem conclui uma compra. Não há chat, checkout ou verificação documental do anunciante nesta etapa. Antes de habilitar anúncios reais de venda, configure políticas de moderação, verificação dos responsáveis e conformidade com a legislação aplicável e regras locais de bem-estar animal. Atualize as regras do Firebase no Console após revisar o arquivo.
