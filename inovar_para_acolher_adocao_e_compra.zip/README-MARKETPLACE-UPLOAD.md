# Inovar para Acolher — Marketplace de adoção (Etapa 2)

Esta atualização transforma a tela inicial em um catálogo estilo marketplace de adoção responsável e torna **obrigatório o envio de uma foto pelo seletor da galeria** ao cadastrar um animal.

## O que mudou
- Vitrine em cartões com foto, nome, espécie, idade, cidade e indicação de adoção gratuita.
- Busca por nome, espécie ou cidade e filtros por cachorro, gato e outros.
- Tela de anúncio com identidade visual renovada.
- Cadastro exige nome, idade aproximada, cidade, descrição e pelo menos uma foto.
- A foto é selecionada pelo `image_picker`, enviada ao Firebase Storage e sua URL é salva no Firestore automaticamente. O usuário não digita URL.
- Mantidas as telas e serviços existentes da Etapa 1 (solicitações de adoção e registros de saúde).

## Como aplicar no Codespaces
1. Faça backup/commit do projeto atual.
2. Extraia este ZIP em uma pasta temporária.
3. Copie as pastas `lib/` e `firebase/` para o projeto, substituindo os arquivos correspondentes. Preserve `android/`, `ios/`, `lib/firebase_options.dart`, `google-services.json`, keystore e arquivos locais de configuração.
4. Confirme que o Firebase Storage está habilitado no projeto Firebase.
5. Publique as regras de Storage abaixo no Firebase Console > Storage > Rules (ou use `firebase deploy --only storage` se o `firebase.json` estiver configurado para esse arquivo).
6. No terminal, execute `flutter pub get`, `dart format lib` e `flutter analyze`.

## Regras do Firebase Storage
O arquivo `firebase/storage.rules` permite leitura pública das fotos dos anúncios e escrita somente pelo usuário autenticado na própria pasta, limitando arquivos a 5 MB e tipos `image/*`. Revise essas regras antes de colocar o app em produção.

```text
rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {
    match /animals/{userId}/{fileName} {
      allow read: if true;
      allow write: if request.auth != null
        && request.auth.uid == userId
        && request.resource.size < 5 * 1024 * 1024
        && request.resource.contentType.matches('image/.*');
    }
  }
}
```

## Importante
- Esta entrega não altera nem cria keystore e não substitui as configurações Firebase específicas da sua instalação.
- Não foi possível executar `flutter analyze` neste ambiente porque o Flutter/Dart SDK não está instalado aqui. Faça a verificação no seu Codespaces e envie qualquer erro para correção.
- A foto obrigatória nesta etapa é uma imagem principal por anúncio. Galeria com várias fotos, chat interno, favoritos e moderação serão etapas posteriores.
