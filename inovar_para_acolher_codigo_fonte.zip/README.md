# Inovar para Acolher — versão inicial

Este é um ponto de partida funcional em Flutter para Android. Inclui:
- cadastro e login por e-mail/senha (Firebase Authentication);
- catálogo de animais disponíveis (Cloud Firestore);
- cadastro básico de animais;
- solicitação de adoção;
- QR Code com identificador do animal.

## Importante
O projeto ainda não está pronto para publicação. Antes de usar com abrigos reais, é necessário:
1. configurar Firebase e gerar `lib/firebase_options.dart`;
2. publicar e testar as regras de segurança;
3. criar papéis e permissões de administrador/abrigo;
4. implementar upload de fotos (o formulário inicial aceita URL);
5. implementar análise e aprovação de solicitações;
6. criar política de privacidade, termos e processo de exclusão de conta;
7. testar em aparelhos reais e cumprir as políticas da Google Play.

## Passo 1 — Criar Firebase
1. Entre em https://console.firebase.google.com/ usando sua conta Google.
2. Crie um projeto chamado `inovar-para-acolher`.
3. Adicione um app Android. O identificador de pacote será `com.inovarparaacolher.app`.
4. Ative Authentication > Sign-in method > Email/Password.
5. Crie Firestore Database em modo de produção.
6. No computador ou ambiente de desenvolvimento com Flutter, instale FlutterFire CLI e execute:
   `dart pub global activate flutterfire_cli`
   `flutterfire configure`
   Escolha o projeto e Android. Isso gera `lib/firebase_options.dart`.
7. Publique as regras de `firebase/firestore.rules` no Firestore Rules e as regras de `firebase/storage.rules` no Storage Rules.

## Passo 2 — Executar
Em um ambiente com Flutter instalado:
```bash
flutter pub get
flutter run
```

## Passo 3 — Preparar Android
Confira `android/app/build.gradle` e defina o `applicationId` como:
`com.inovarparaacolher.app`
Depois configure assinatura de release e gere o pacote:
```bash
flutter build appbundle --release
```
O arquivo AAB será criado em `build/app/outputs/bundle/release/app-release.aab`.

## Como trabalhar somente pelo celular Android
É possível ler/editar os arquivos pelo celular, mas compilar Flutter e gerar um AAB diretamente no Android é limitado. Use um ambiente de desenvolvimento em nuvem acessado pelo Chrome, ou peça acesso temporário a um computador. Não envie senhas, chaves privadas ou arquivos de assinatura para repositórios públicos.

## Modelo inicial de dados
`animals/{animalId}`:
- name, species, description, photoUrl, age, city, status, shelterId, createdAt, updatedAt

`adoptionRequests/{requestId}`:
- animalId, animalName, adopterId, adopterEmail, shelterId, message, status, createdAt

## Limitações desta versão
- A tela de cadastro de animais está aberta a qualquer usuário autenticado; isso é apenas para prototipagem. Antes de produção, restringir criação a contas verificadas de abrigos.
- O QR Code é gerado no detalhe do animal, mas ainda não existe leitura de QR nem página pública dedicada.
- Foto por URL é provisória; implementar seleção e upload seguro de imagem.
- A gestão das solicitações pelo abrigo ainda precisa de tela própria.
