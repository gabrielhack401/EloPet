import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../models/animal.dart';

class AnimalService {
  final _db = FirebaseFirestore.instance;

  Stream<List<Animal>> availableAnimals() {
    return _db.collection('animals')
      .where('status', isEqualTo: 'disponivel')
      .snapshots()
      .map((snapshot) => snapshot.docs.map(Animal.fromDoc).toList());
  }

  Future<void> addAnimal(Animal animal) async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) throw StateError('Entre na sua conta primeiro.');
    await _db.collection('animals').add({
      ...animal.toMap(),
      'shelterId': user.uid,
      'createdAt': FieldValue.serverTimestamp(),
    });
  }

  Future<void> requestAdoption(Animal animal, String message) async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) throw StateError('Entre na sua conta para solicitar adoção.');
    await _db.collection('adoptionRequests').add({
      'animalId': animal.id,
      'animalName': animal.name,
      'adopterId': user.uid,
      'adopterEmail': user.email,
      'shelterId': animal.shelterId,
      'message': message.trim(),
      'status': 'pendente',
      'createdAt': FieldValue.serverTimestamp(),
    });
  }
}
