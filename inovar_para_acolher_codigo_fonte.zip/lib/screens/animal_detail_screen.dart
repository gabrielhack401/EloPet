import 'package:flutter/material.dart';
import 'package:qr_flutter/qr_flutter.dart';
import '../models/animal.dart';
import '../services/animal_service.dart';

class AnimalDetailScreen extends StatelessWidget {
  const AnimalDetailScreen({super.key, required this.animal});
  final Animal animal;

  Future<void> _adopt(BuildContext context) async {
    final controller = TextEditingController();
    final message = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Tenho interesse em adotar'),
        content: TextField(controller: controller, maxLines: 4,
          decoration: const InputDecoration(hintText: 'Conte um pouco sobre o lar que oferecerá ao animal.')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancelar')),
          FilledButton(onPressed: () => Navigator.pop(context, controller.text), child: const Text('Enviar')),
        ],
      ),
    );
    if (message == null) return;
    try {
      await AnimalService().requestAdoption(animal, message);
      if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Solicitação enviada ao abrigo!')));
    } catch (e) {
      if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(animal.name)),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(20),
            child: animal.photoUrl.isEmpty
              ? Container(height: 220, color: Colors.green.shade50, child: const Icon(Icons.pets, size: 80))
              : Image.network(animal.photoUrl, height: 260, fit: BoxFit.cover),
          ),
          const SizedBox(height: 18),
          Text(animal.name, style: Theme.of(context).textTheme.headlineMedium),
          Text('${animal.species} • ${animal.age} • ${animal.city}'),
          const SizedBox(height: 16),
          Text(animal.description),
          const SizedBox(height: 24),
          const Text('Identificação QR Code', style: TextStyle(fontWeight: FontWeight.bold)),
          Center(child: QrImageView(data: 'inovar-para-acolher://animal/${animal.id}', size: 170)),
          FilledButton.icon(onPressed: () => _adopt(context),
            icon: const Icon(Icons.favorite), label: const Text('Quero solicitar adoção')),
        ],
      ),
    );
  }
}
