import 'package:flutter/material.dart';
import '../models/animal.dart';
import '../services/animal_service.dart';

class NewAnimalScreen extends StatefulWidget {
  const NewAnimalScreen({super.key});
  @override
  State<NewAnimalScreen> createState() => _NewAnimalScreenState();
}

class _NewAnimalScreenState extends State<NewAnimalScreen> {
  final _name = TextEditingController();
  final _species = TextEditingController(text: 'Cachorro');
  final _age = TextEditingController();
  final _city = TextEditingController();
  final _photo = TextEditingController();
  final _description = TextEditingController();
  bool _busy = false;

  Future<void> _save() async {
    if (_name.text.trim().isEmpty || _species.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Informe pelo menos nome e espécie.')));
      return;
    }
    setState(() => _busy = true);
    try {
      await AnimalService().addAnimal(Animal(
        id: '', name: _name.text.trim(), species: _species.text.trim(),
        description: _description.text.trim(), photoUrl: _photo.text.trim(),
        age: _age.text.trim(), city: _city.text.trim(),
        status: 'disponivel', shelterId: '',
      ));
      if (mounted) Navigator.pop(context);
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Erro: $e')));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  void dispose() {
    for (final c in [_name, _species, _age, _city, _photo, _description]) { c.dispose(); }
    super.dispose();
  }

  Widget _field(TextEditingController c, String label, {int lines = 1}) =>
    Padding(padding: const EdgeInsets.only(bottom: 12),
      child: TextField(controller: c, maxLines: lines, decoration: InputDecoration(labelText: label)));

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Cadastrar animal')),
      body: ListView(padding: const EdgeInsets.all(20), children: [
        _field(_name, 'Nome do animal'),
        _field(_species, 'Espécie (cachorro, gato...)'),
        _field(_age, 'Idade aproximada'),
        _field(_city, 'Cidade'),
        _field(_photo, 'URL da foto (opcional)'),
        _field(_description, 'História e características', lines: 4),
        FilledButton(onPressed: _busy ? null : _save,
          child: _busy ? const CircularProgressIndicator() : const Text('Salvar cadastro')),
      ]),
    );
  }
}
