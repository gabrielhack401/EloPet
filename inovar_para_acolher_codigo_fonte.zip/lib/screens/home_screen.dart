import 'package:flutter/material.dart';
import '../models/animal.dart';
import '../services/animal_service.dart';
import '../services/auth_service.dart';
import 'animal_detail_screen.dart';
import 'new_animal_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Inovar para Acolher', style: TextStyle(fontWeight: FontWeight.bold)),
        actions: [
          IconButton(tooltip: 'Sair', onPressed: () => AuthService().signOut(),
            icon: const Icon(Icons.logout)),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const NewAnimalScreen())),
        icon: const Icon(Icons.add), label: const Text('Cadastrar animal'),
      ),
      body: StreamBuilder<List<Animal>>(
        stream: AnimalService().availableAnimals(),
        builder: (context, snapshot) {
          if (snapshot.hasError) return const Center(child: Text('Erro ao carregar animais. Confira a configuração do Firebase.'));
          if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
          final animals = snapshot.data!;
          if (animals.isEmpty) {
            return const Center(child: Padding(
              padding: EdgeInsets.all(28),
              child: Text('Ainda não há animais cadastrados. Use “Cadastrar animal” para adicionar o primeiro.', textAlign: TextAlign.center),
            ));
          }
          return ListView.builder(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 100),
            itemCount: animals.length,
            itemBuilder: (context, index) {
              final animal = animals[index];
              return Card(
                clipBehavior: Clip.antiAlias,
                margin: const EdgeInsets.only(bottom: 14),
                child: ListTile(
                  contentPadding: const EdgeInsets.all(12),
                  leading: animal.photoUrl.isEmpty
                    ? const CircleAvatar(child: Icon(Icons.pets))
                    : CircleAvatar(backgroundImage: NetworkImage(animal.photoUrl)),
                  title: Text(animal.name, style: const TextStyle(fontWeight: FontWeight.bold)),
                  subtitle: Text('${animal.species} • ${animal.age}\n${animal.city}'),
                  isThreeLine: true,
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () => Navigator.push(context, MaterialPageRoute(
                    builder: (_) => AnimalDetailScreen(animal: animal))),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
