import 'package:cloud_firestore/cloud_firestore.dart';

class Animal {
  const Animal({
    required this.id,
    required this.name,
    required this.species,
    required this.description,
    required this.photoUrl,
    required this.age,
    required this.city,
    required this.status,
    required this.shelterId,
  });

  final String id;
  final String name;
  final String species;
  final String description;
  final String photoUrl;
  final String age;
  final String city;
  final String status;
  final String shelterId;

  factory Animal.fromDoc(DocumentSnapshot<Map<String, dynamic>> doc) {
    final data = doc.data() ?? {};
    return Animal(
      id: doc.id,
      name: data['name'] as String? ?? 'Animal sem nome',
      species: data['species'] as String? ?? 'Não informado',
      description: data['description'] as String? ?? '',
      photoUrl: data['photoUrl'] as String? ?? '',
      age: data['age'] as String? ?? 'Não informada',
      city: data['city'] as String? ?? '',
      status: data['status'] as String? ?? 'disponivel',
      shelterId: data['shelterId'] as String? ?? '',
    );
  }

  Map<String, dynamic> toMap() => {
    'name': name,
    'species': species,
    'description': description,
    'photoUrl': photoUrl,
    'age': age,
    'city': city,
    'status': status,
    'shelterId': shelterId,
    'updatedAt': FieldValue.serverTimestamp(),
  };
}
